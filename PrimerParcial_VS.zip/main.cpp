#include <iostream>
using namespace std;

int main()
{
   return 0;
}

